#include <iostream>
#include <stdlib.h> 
using namespace std;


//////// START OF MARKER FOR fib


//////// END OF MARKER 



//////// DO NOT MODIFY CODE BEYOND THIS LINE

int main(int argc, char* argv[]) {
    cout << (fib(atoi(argv[1]))) <<endl;
    return 0;
}
