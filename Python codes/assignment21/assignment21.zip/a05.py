## IMPORTS GO HERE

## END OF IMPORTS

#### YOUR CODE FOR is_prime() FUNCTION GOES HERE ####

#### End OF MARKER

#### YOUR CODE FOR output_factors() FUNCTION GOES HERE ####

#### End OF MARKER

#### YOUR CODE FOR get_largest_prime() FUNCTION GOES HERE ####

#### End OF MARKER



if __name__ == '__main__':
    print is_prime(499)  # should return True

    print get_largest_prime(10)  # should return 7
    # print get_largest_prime(100000)  # bonus, try with 100k

    output_factors(10)  # should output -- 1 2 5 10 -- one on each line
