## IMPORTS GO HERE

## END OF IMPORTS

### YOUR CODE FOR output_prime_factors() FUNCTION GOES HERE ###

#### End OF MARKER


### YOUR CODE FOR get_nth_prime() FUNCTION GOES HERE ###

#### End OF MARKER


if __name__ == '__main__':
    output_prime_factors(23)
    print get_nth_prime(4)
