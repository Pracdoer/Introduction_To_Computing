## IMPORTS GO HERE

## END OF IMPORTS


#### YOUR CODE FOR sqrt() FUNCTION GOES HERE ####


#### End OF MARKER

#### YOUR CODE FOR average() FUNCTION GOES HERE ####


#### End OF MARKER


#### YOUR CODE FOR improve_guess() FUNCTION GOES HERE ####



#### End OF MARKER




if __name__ == '__main__':
    print sqrt(36)
