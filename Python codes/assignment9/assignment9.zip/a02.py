## IMPORTS GO HERE

## END OF IMPORTS 


#### YOUR CODE FOR get_area GOES HERE ####

#### End OF MARKER


#### YOUR CODE FOR output_parameter GOES HERE ####

#### End OF MARKER  




if __name__ == '__main__': 
    print get_area(2) 
    output_parameter(1.0) 

